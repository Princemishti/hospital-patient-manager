class Patient:

    def __init__(self, id, name, age, disease):
        self.id = id
        self.name = name
        self.age = age
        self.disease = disease

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "age": self.age,
            "disease": self.disease
        }
