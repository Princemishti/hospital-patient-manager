import json
import os
from models import Patient

FILE_NAME = "patients.json"

def load_patients():

    if not os.path.exists(FILE_NAME):
        return []

    with open(FILE_NAME, "r") as file:
        data = json.load(file)

    patients = []

    for p in data:
        patients.append(Patient(p["id"], p["name"], p["age"], p["disease"]))

    return patients


def save_patients(patients):

    data = []

    for p in patients:
        data.append(p.to_dict())

    with open(FILE_NAME, "w") as file:
        json.dump(data, file, indent=4)
