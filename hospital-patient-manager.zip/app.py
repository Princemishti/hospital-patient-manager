from flask import Flask, render_template, request, redirect
from manager import PatientManager

app = Flask(__name__)
manager = PatientManager()

@app.route("/")
def home():
    patients = manager.get_all_patients()
    return render_template("index.html", patients=patients)

@app.route("/add", methods=["POST"])
def add_patient():
    name = request.form["name"]
    age = request.form["age"]
    disease = request.form["disease"]

    manager.add_patient(name, age, disease)
    return redirect("/")

@app.route("/delete/<patient_id>")
def delete_patient(patient_id):
    manager.delete_patient(patient_id)
    return redirect("/")

if __name__ == "__main__":
    app.run(debug=True)
