import uuid
from models import Patient
from storage import load_patients, save_patients

class PatientManager:

    def __init__(self):
        self.patients = load_patients()

    def add_patient(self, name, age, disease):
        patient_id = str(uuid.uuid4())
        patient = Patient(patient_id, name, age, disease)
        self.patients.append(patient)
        save_patients(self.patients)

    def delete_patient(self, patient_id):
        self.patients = [p for p in self.patients if p.id != patient_id]
        save_patients(self.patients)

    def get_all_patients(self):
        return self.patients
